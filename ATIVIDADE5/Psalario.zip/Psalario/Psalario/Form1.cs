﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario
{
    public partial class Form1 : Form
    {
        double salarioBruto, salarioLiquido, descontoINSS, descontoIRPF, salarioFamilia, numFilhos;

        private void nudFilhos_Validated(object sender, EventArgs e)
        {
            numFilhos = Convert.ToDouble(nudFilhos.Value);
        }

        private void mskSalarioBruto_Validated(object sender, EventArgs e)
        {
            if ((!double.TryParse(mskSalarioBruto.Text, out salarioBruto)) || (salarioBruto == 0))
            {
                MessageBox.Show("Salário Inválido!");
                mskSalarioBruto.Focus();
            }
        }



        public Form1()
        {
            InitializeComponent();
        }

        private void txtNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsNumber(e.KeyChar) || Char.IsPunctuation(e.KeyChar))
            {
                MessageBox.Show("Caracter Inválido!");
                SendKeys.Send("{BACKSPACE}");
            }
        }


        private void btnVerificar_Click(object sender, EventArgs e)
        {
           if(salarioBruto <= 800.47)
            {
                txtAliqINSS.Text = "7,65%";
                descontoINSS = 0.0765 * salarioBruto;
                txtDescINSS.Text = descontoINSS.ToString("N2");
            }
            else if (salarioBruto <= 1050)
            {
                txtAliqINSS.Text = "8,65%";
                descontoINSS = 0.0865 * salarioBruto;
                txtDescINSS.Text = descontoINSS.ToString("N2");
            }
            else if (salarioBruto <= 1400.77)
            {
                txtAliqINSS.Text = "9,00%";
                descontoINSS = 0.09 * salarioBruto;
                txtDescINSS.Text = descontoINSS.ToString("N2");
            }
            else if (salarioBruto <= 2801.56)
            {
                txtAliqINSS.Text = "11,00%";
                descontoINSS = 0.11 * salarioBruto;
                txtDescINSS.Text = descontoINSS.ToString("N2");
            }
            else
            {
                txtAliqINSS.Text = "Teto";
                descontoINSS = 308.17;
                txtDescINSS.Text = descontoINSS.ToString("N2");
            }

            if (salarioBruto <= 1257.12)
            {
                txtAliqIRPF.Text = "Isento";
                descontoIRPF = 0;
                txtDescIRPF.Text = descontoIRPF.ToString("N2");
            }
            else if (salarioBruto <= 2512.08)
            {
                txtAliqIRPF.Text = "15,00%";
                descontoIRPF = 0.15 * salarioBruto;
                txtDescIRPF.Text = descontoIRPF.ToString("N2");
            }
            else
            {
                txtAliqIRPF.Text = "27,50%";
                descontoIRPF = 0.275 * salarioBruto;
                txtDescIRPF.Text = descontoIRPF.ToString("N2");
            }

            if (salarioBruto <= 435.52)
            {
                salarioFamilia = numFilhos * 22.33;
                txtSalFamilia.Text = salarioFamilia.ToString("N2");
            }
            else if (salarioBruto <= 654.61)
            {
                salarioFamilia = numFilhos * 15.74;
                txtSalFamilia.Text = salarioFamilia.ToString("N2");
            }
            else
            {
                salarioFamilia = 0;
                txtSalFamilia.Text = salarioFamilia.ToString("N2");
            }

            salarioLiquido = salarioBruto - descontoINSS - descontoIRPF + salarioFamilia;
            txtSalLiquido.Text = salarioLiquido.ToString("N2");
        }
    }
}
