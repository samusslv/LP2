﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double ValorA, ValorB, ValorC;


        public Form1()
        {
            InitializeComponent();
        }

        private void txtValorA_Validated(object sender, EventArgs e)
        {
            if ((!double.TryParse(txtValorA.Text, out ValorA)) || (ValorA <= 0))
            {
                MessageBox.Show("Valor A Inválido");
                txtValorA.Focus();
            }
        }

        private void txtValorB_Validated(object sender, EventArgs e)
        {
            if ((!double.TryParse(txtValorB.Text, out ValorB)) || (ValorB <= 0))
            {
                MessageBox.Show("Valor B Inválido");
                txtValorB.Focus();
            }
        }

        private void txtValorC_Validated(object sender, EventArgs e)
        {
            if ((!double.TryParse(txtValorC.Text, out ValorC)) || (ValorC <= 0))
            {
                MessageBox.Show("Valor C Inválido");
                txtValorC.Focus();
            }
        }



        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if ((ValorA < (ValorB + ValorC)) && (ValorA > Math.Abs(ValorB - ValorC)) &&
               (ValorB < (ValorA + ValorC)) && (ValorB > Math.Abs(ValorA - ValorC)) &&
               (ValorC < (ValorA + ValorB)) && (ValorC > Math.Abs(ValorA - ValorB)))
                            
                {
                    if (ValorA == ValorB && ValorB == ValorC)
                        MessageBox.Show("É um Triângulo Equilatero");
                    else if (ValorA == ValorB || ValorA == ValorC || ValorB == ValorC)
                        MessageBox.Show("É um Triângulo Isósceles");
                    else
                        MessageBox.Show("É um Triangulo Escaleno");
                }

            else
                MessageBox.Show("Verificar valores, triângulo inválido");
                btnExecutar.Focus();


        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você realmente deseja sair", "Saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                Close();
        }
    }
}
