﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade2_Pcalc
{
    public partial class Form1 : Form
    {
        Double Numero1, Numero2, Resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(txtNumero1.Text, out Numero1))
            { MessageBox.Show("Número 1 invalido!");
                txtNumero1.Focus();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
            txtResultado.Clear();
        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumero2.Text, out Numero2))
            {
                MessageBox.Show("Número 2 invalido!");
                txtNumero2.Focus();
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 + Numero2;
            txtResultado.Text = Resultado.ToString();
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 * Numero2;
            txtResultado.Text = Resultado.ToString();
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 - Numero2;
            txtResultado.Text = Resultado.ToString();
        }

        private void txtResultado_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (Numero2 == 0)
            {
                MessageBox.Show("Número 2 precisa ser diferente de zero!");
                txtNumero2.Focus();
            }
            else
            {
                Resultado = Numero1 / Numero2;
                txtResultado.Text = Resultado.ToString();
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você realmente deseja sair", "Saída",
                MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.Yes)Close();
        }
    }
}
