﻿namespace Pclasses
{
    partial class frmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnEstanciar1 = new System.Windows.Forms.Button();
            this.txtNumHoras = new System.Windows.Forms.TextBox();
            this.txtSalarioHora = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.lblDataEntrada = new System.Windows.Forms.Label();
            this.lblSalarioHora = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblMAtricula = new System.Windows.Forms.Label();
            this.lblData = new System.Windows.Forms.Label();
            this.lblDias = new System.Windows.Forms.Label();
            this.txtData = new System.Windows.Forms.TextBox();
            this.txtDias = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnEstanciar1
            // 
            this.btnEstanciar1.Location = new System.Drawing.Point(120, 235);
            this.btnEstanciar1.Name = "btnEstanciar1";
            this.btnEstanciar1.Size = new System.Drawing.Size(181, 51);
            this.btnEstanciar1.TabIndex = 18;
            this.btnEstanciar1.Text = "Intanciar Horista";
            this.btnEstanciar1.UseVisualStyleBackColor = true;
            this.btnEstanciar1.Click += new System.EventHandler(this.btnEstanciar1_Click);
            // 
            // txtNumHoras
            // 
            this.txtNumHoras.Location = new System.Drawing.Point(225, 125);
            this.txtNumHoras.Name = "txtNumHoras";
            this.txtNumHoras.Size = new System.Drawing.Size(178, 22);
            this.txtNumHoras.TabIndex = 17;
            // 
            // txtSalarioHora
            // 
            this.txtSalarioHora.Location = new System.Drawing.Point(225, 90);
            this.txtSalarioHora.Name = "txtSalarioHora";
            this.txtSalarioHora.Size = new System.Drawing.Size(178, 22);
            this.txtSalarioHora.TabIndex = 16;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(225, 55);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(178, 22);
            this.txtNome.TabIndex = 15;
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(225, 22);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(178, 22);
            this.txtMatricula.TabIndex = 14;
            // 
            // lblDataEntrada
            // 
            this.lblDataEntrada.AutoSize = true;
            this.lblDataEntrada.Location = new System.Drawing.Point(26, 128);
            this.lblDataEntrada.Name = "lblDataEntrada";
            this.lblDataEntrada.Size = new System.Drawing.Size(114, 16);
            this.lblDataEntrada.TabIndex = 13;
            this.lblDataEntrada.Text = "Numero de Horas";
            // 
            // lblSalarioHora
            // 
            this.lblSalarioHora.AutoSize = true;
            this.lblSalarioHora.Location = new System.Drawing.Point(26, 93);
            this.lblSalarioHora.Name = "lblSalarioHora";
            this.lblSalarioHora.Size = new System.Drawing.Size(106, 16);
            this.lblSalarioHora.TabIndex = 12;
            this.lblSalarioHora.Text = "Salário por Hora";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(26, 58);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(44, 16);
            this.lblNome.TabIndex = 11;
            this.lblNome.Text = "Nome";
            // 
            // lblMAtricula
            // 
            this.lblMAtricula.AutoSize = true;
            this.lblMAtricula.Location = new System.Drawing.Point(26, 25);
            this.lblMAtricula.Name = "lblMAtricula";
            this.lblMAtricula.Size = new System.Drawing.Size(61, 16);
            this.lblMAtricula.TabIndex = 10;
            this.lblMAtricula.Text = "Matrícula";
            // 
            // lblData
            // 
            this.lblData.AutoSize = true;
            this.lblData.Location = new System.Drawing.Point(26, 163);
            this.lblData.Name = "lblData";
            this.lblData.Size = new System.Drawing.Size(181, 16);
            this.lblData.TabIndex = 19;
            this.lblData.Text = "Data de Entrada na Empresa";
            // 
            // lblDias
            // 
            this.lblDias.AutoSize = true;
            this.lblDias.Location = new System.Drawing.Point(26, 197);
            this.lblDias.Name = "lblDias";
            this.lblDias.Size = new System.Drawing.Size(94, 16);
            this.lblDias.TabIndex = 20;
            this.lblDias.Text = "Dias de Faltas";
            // 
            // txtData
            // 
            this.txtData.Location = new System.Drawing.Point(225, 160);
            this.txtData.Name = "txtData";
            this.txtData.Size = new System.Drawing.Size(178, 22);
            this.txtData.TabIndex = 21;
            // 
            // txtDias
            // 
            this.txtDias.Location = new System.Drawing.Point(225, 194);
            this.txtDias.Name = "txtDias";
            this.txtDias.Size = new System.Drawing.Size(178, 22);
            this.txtDias.TabIndex = 22;
            // 
            // frmHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(442, 312);
            this.Controls.Add(this.txtDias);
            this.Controls.Add(this.txtData);
            this.Controls.Add(this.lblDias);
            this.Controls.Add(this.lblData);
            this.Controls.Add(this.btnEstanciar1);
            this.Controls.Add(this.txtNumHoras);
            this.Controls.Add(this.txtSalarioHora);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.lblDataEntrada);
            this.Controls.Add(this.lblSalarioHora);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblMAtricula);
            this.Name = "frmHorista";
            this.Text = "frmHorista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnEstanciar1;
        private System.Windows.Forms.TextBox txtNumHoras;
        private System.Windows.Forms.TextBox txtSalarioHora;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.Label lblDataEntrada;
        private System.Windows.Forms.Label lblSalarioHora;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblMAtricula;
        private System.Windows.Forms.Label lblData;
        private System.Windows.Forms.Label lblDias;
        private System.Windows.Forms.TextBox txtData;
        private System.Windows.Forms.TextBox txtDias;
    }
}