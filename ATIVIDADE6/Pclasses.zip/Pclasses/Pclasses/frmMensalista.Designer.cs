﻿namespace Pclasses
{
    partial class frmMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMAtricula = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalarioMensal = new System.Windows.Forms.Label();
            this.lblDataEntrada = new System.Windows.Forms.Label();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtSalarioMensal = new System.Windows.Forms.TextBox();
            this.txtEntradaEmpresa = new System.Windows.Forms.TextBox();
            this.btnEstanciar1 = new System.Windows.Forms.Button();
            this.btnEstanciar2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblMAtricula
            // 
            this.lblMAtricula.AutoSize = true;
            this.lblMAtricula.Location = new System.Drawing.Point(34, 32);
            this.lblMAtricula.Name = "lblMAtricula";
            this.lblMAtricula.Size = new System.Drawing.Size(61, 16);
            this.lblMAtricula.TabIndex = 0;
            this.lblMAtricula.Text = "Matrícula";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(34, 62);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(44, 16);
            this.lblNome.TabIndex = 1;
            this.lblNome.Text = "Nome";
            // 
            // lblSalarioMensal
            // 
            this.lblSalarioMensal.AutoSize = true;
            this.lblSalarioMensal.Location = new System.Drawing.Point(34, 97);
            this.lblSalarioMensal.Name = "lblSalarioMensal";
            this.lblSalarioMensal.Size = new System.Drawing.Size(97, 16);
            this.lblSalarioMensal.TabIndex = 2;
            this.lblSalarioMensal.Text = "Salário Mensal";
            // 
            // lblDataEntrada
            // 
            this.lblDataEntrada.AutoSize = true;
            this.lblDataEntrada.Location = new System.Drawing.Point(34, 134);
            this.lblDataEntrada.Name = "lblDataEntrada";
            this.lblDataEntrada.Size = new System.Drawing.Size(181, 16);
            this.lblDataEntrada.TabIndex = 3;
            this.lblDataEntrada.Text = "Data de Entrada na Empresa";
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(233, 29);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(178, 22);
            this.txtMatricula.TabIndex = 4;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(233, 59);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(178, 22);
            this.txtNome.TabIndex = 5;
            // 
            // txtSalarioMensal
            // 
            this.txtSalarioMensal.Location = new System.Drawing.Point(233, 94);
            this.txtSalarioMensal.Name = "txtSalarioMensal";
            this.txtSalarioMensal.Size = new System.Drawing.Size(178, 22);
            this.txtSalarioMensal.TabIndex = 6;
            // 
            // txtEntradaEmpresa
            // 
            this.txtEntradaEmpresa.Location = new System.Drawing.Point(233, 131);
            this.txtEntradaEmpresa.Name = "txtEntradaEmpresa";
            this.txtEntradaEmpresa.Size = new System.Drawing.Size(178, 22);
            this.txtEntradaEmpresa.TabIndex = 7;
            // 
            // btnEstanciar1
            // 
            this.btnEstanciar1.Location = new System.Drawing.Point(37, 165);
            this.btnEstanciar1.Name = "btnEstanciar1";
            this.btnEstanciar1.Size = new System.Drawing.Size(181, 51);
            this.btnEstanciar1.TabIndex = 8;
            this.btnEstanciar1.Text = "Intanciar Mensalista";
            this.btnEstanciar1.UseVisualStyleBackColor = true;
            this.btnEstanciar1.Click += new System.EventHandler(this.btnEstanciar1_Click);
            // 
            // btnEstanciar2
            // 
            this.btnEstanciar2.Location = new System.Drawing.Point(233, 165);
            this.btnEstanciar2.Name = "btnEstanciar2";
            this.btnEstanciar2.Size = new System.Drawing.Size(178, 51);
            this.btnEstanciar2.TabIndex = 9;
            this.btnEstanciar2.Text = "Instanciar Mensalista passando parâmetros";
            this.btnEstanciar2.UseVisualStyleBackColor = true;
            this.btnEstanciar2.Click += new System.EventHandler(this.btnEstanciar2_Click);
            // 
            // frmMensalista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(456, 249);
            this.Controls.Add(this.btnEstanciar2);
            this.Controls.Add(this.btnEstanciar1);
            this.Controls.Add(this.txtEntradaEmpresa);
            this.Controls.Add(this.txtSalarioMensal);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.lblDataEntrada);
            this.Controls.Add(this.lblSalarioMensal);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblMAtricula);
            this.Name = "frmMensalista";
            this.Text = "frmMensalista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMAtricula;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalarioMensal;
        private System.Windows.Forms.Label lblDataEntrada;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtSalarioMensal;
        private System.Windows.Forms.TextBox txtEntradaEmpresa;
        private System.Windows.Forms.Button btnEstanciar1;
        private System.Windows.Forms.Button btnEstanciar2;
    }
}